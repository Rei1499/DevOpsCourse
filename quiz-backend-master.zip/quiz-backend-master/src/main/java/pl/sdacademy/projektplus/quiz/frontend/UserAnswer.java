package pl.sdacademy.projektplus.quiz.frontend;

import lombok.Data;

@Data
public class UserAnswer {
    private String answer;
}
